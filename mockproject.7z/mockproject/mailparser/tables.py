import django_tables2 as tables
import itertools
from django.utils.html import format_html
from .models import Document
from django_tables2 import A
from django.urls import reverse



class DocumentTable(tables.Table):
    row_number = tables.Column(empty_values=(),
                                verbose_name='Row')
    
    view_document = tables.TemplateColumn('<form method="post" action="." > {% csrf_token %} <input type="hidden" name = "obj_id" value={{ record.id}}><input type="submit" value="View"></form>')
    
    
    def __init__(self, *args, **kwargs):
        super(DocumentTable, self).__init__(*args, **kwargs)
        self.counter = itertools.count()

    def render_row_number(self):
        return '%d' % next(self.counter)

        
    
    
   
    class Meta:
        model = Document
        sequence = ('row_number','description')
        attrs = {'class': 'paleblue'}
        
        exclude = ('id',)
