# -*- coding: utf-8 -*-
from __future__ import unicode_literals


import os
import datetime as dt
from django.core.exceptions import ValidationError
from django.db import models

class Document(models.Model):
    def validate_file_extension(value):
        '''Validated The File Name Extension'''
        ext = os.path.splitext(value.name)[1]  # [0] returns path+filename
        valid_extensions = ['.msg',]
        if not ext.lower() in valid_extensions:
            raise ValidationError(u'Unsupported file extension.')
        
    description = models.CharField(max_length=255, blank=True)
    document = models.FileField(upload_to='.',
                                    validators=[validate_file_extension])
    uploaded_at = models.DateTimeField(auto_now_add=True)
    
    
    class Meta:
        ordering = ('-uploaded_at',)
        
    def __str__(self):
        return 'File - {} -{}'.format(self.description, self.uploaded_at.strftime('%B %d, %Y - %H:%M:%S'))
    
    