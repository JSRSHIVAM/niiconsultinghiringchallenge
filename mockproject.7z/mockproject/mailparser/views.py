# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.shortcuts import render, redirect
from .forms import DocumentForm
from django_tables2 import SingleTableView
from django.urls import reverse
from django.views.generic import ListView
from .models import Document
from .tables import DocumentTable
from django.conf import settings
import pythoncom
import threading 
import pythoncom 
import email
from django.utils.encoding import smart_unicode
import os
import win32com.client
import pywintypes
from collections import OrderedDict
import shutil
def model_form_upload(request):
    if request.method == 'POST':
        form = DocumentForm(request.POST, request.FILES)
        if form.is_valid():
            form.save()
            return redirect('home')
    else:
        form = DocumentForm()
    return render(request, 'model_form_upload.html', {
        'form': form
    })

    
def view_detailed_mail(request,*args,**kwargs):
    pythoncom.CoInitialize()
    mapi = win32com.client.Dispatch(
        "Outlook.Application").GetNamespace("MAPI")
    #msg = mapi.OpenSharedItem(os.path.abspath(args.MSG_FILE))
    
    msg_id = request.POST.get(obj_id,None) 
    print(msg_id)
    print(request.POST)
    return render(request, 'model_form_upload.html', {})
 
    

class ManageDocumentView(SingleTableView, ListView):
    model = Document
    context_object_name = 'table'
    paginate_by = 3
    template_name = 'manage_document.html'
    table_class = DocumentTable
    
    def dispatch(self, *args, **kwargs):
        return super(ManageDocumentView, self).dispatch(*args, **kwargs)

    def post(self, *args, **kwargs):
        #print(self.request.POST)
        
        pythoncom.CoInitialize()
        mapi = win32com.client.Dispatch(
            "Outlook.Application").GetNamespace("MAPI")
        #msg = mapi.OpenSharedItem(os.path.abspath(args.MSG_FILE))
        
        msg_id = int(self.request.POST.get('obj_id',None))
        object_detail = Document.objects.get(pk = msg_id)
        
        filename = str(os.path.join(settings.MEDIA_ROOT ,object_detail.document.name))
        #obj  = object_detail.document.file.read()
        print(filename)
        
        
        msg = mapi.OpenSharedItem(filename)
      
        header_data = display_msg_attribs(msg)
        recipient_info = display_msg_recipients(msg)
        body_data = extract_msg_body(msg)
        
        
        print(header_data)
        return render(self.request, 'model_form_detailed.html', {'header_data': header_data, 'recipient_info': recipient_info,
           'msg_body':body_data
        })
        
        
   
def display_msg_attribs(msg):
    # Display Message Attributes
    attribs = [
        'Application', 'AutoForwarded', 'BCC', 'CC', 'Class',
        'ConversationID', 'ConversationTopic', 'CreationTime',
        'ExpiryTime', 'Importance', 'InternetCodePage', 'IsMarkedAsTask',
        'LastModificationTime', 'Links', 'OriginalDeliveryReportRequested',
        'ReadReceiptRequested', 'ReceivedTime', 'ReminderSet',
        'ReminderTime', 'ReplyRecipientNames', 'Saved', 'Sender',
        'SenderEmailAddress', 'SenderEmailType', 'SenderName', 'Sent',
        'SentOn', 'SentOnBehalfOfName', 'Size', 'Subject',
        'TaskCompletedDate', 'TaskDueDate', 'To', 'UnRead'
    ]
    print("\nMessage Attributes")
    print("==================")
    
    header_data = dict()
    for entry in attribs:
        val = getattr(msg, entry, 'N/A')
        print("{}: {}".format(entry, getattr(msg, entry, 'N/A')))
        header_data[str(entry)] = str(val)
        
    return header_data
           
           
       
def display_msg_recipients(msg):
    # Display Recipient Information
    recipient_attrib = [
        'Address', 'AutoResponse', 'Name', 'Resolved', 'Sendable'
    ]
    i = 1
    while True:
        try:
            recipient = msg.Recipients(i)
        except pywintypes.com_error:
            break
        
        header_data = dict()
        print("\nRecipient {}".format(i))
        print("=" * 15)
        for entry in recipient_attrib:
            val = getattr(recipient, entry, 'N/A')
            print("{}: {}".format(entry, getattr(recipient, entry, 'N/A')))
            header_data[str(entry)] = str(val)
        i += 1
        
    return header_data
    
    
    
         
def extract_msg_body(msg):
    # Extract HTML Data
    html_data = msg.HTMLBody.encode('cp1252')
   
    body_data = msg.Body.encode('cp1252')
    return msg.HTMLBody
    
    
     
def extract_attachments(msg, out_dir):
    attachment_attribs = [
        'DisplayName', 'FileName', 'PathName', 'Position', 'Size'
    ]
    i = 1 # Attachments start at 1
    while True:
        try:
            attachment = msg.Attachments(i)
        except pywintypes.com_error:
            break
        print("\nAttachment {}".format(i))
        print("=" * 15)
        for entry in attachment_attribs:
            print('{}: {}'.format(entry, getattr(attachment, entry,
                                                 "N/A")))
        outfile = os.path.join(os.path.abspath(out_dir),
                               os.path.split(args.MSG_FILE)[-1])
        if not os.path.exists(outfile):
            os.makedirs(outfile)
        outfile = os.path.join(outfile, attachment.FileName)
        attachment.SaveAsFile(outfile)
        print("Exported: {}".format(outfile))
        i += 1