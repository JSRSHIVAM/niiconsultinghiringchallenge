from django.conf.urls import url
from .views import model_form_upload, ManageDocumentView, view_detailed_mail

urlpatterns = [
    url(r'^upload/$', model_form_upload, name='upload_mail_view'),
    url(r'^$', model_form_upload,name="home"),
    url(r'^manage/$', ManageDocumentView.as_view(), name='manage_mail_view'),
    url(r'^manage/(?P<mid>\d+)/$', view_detailed_mail, name='view_detailed_mail'),
   ]